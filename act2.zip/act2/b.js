function evalue(){
    var input = document.getElementById("nombre");
    var value = input.value;
    alert ("bienvenido: " + value);
}